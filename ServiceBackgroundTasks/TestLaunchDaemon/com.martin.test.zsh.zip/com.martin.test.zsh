#!/bin/zsh

# Log file to use
logFile="/tmp/com.martin.test.log"

# Add a line to the log file
echo date +%Y-%m-%d_%H:%M:%S >>"$logFile"
